from django.urls import path
from . import views

app_name='schoolweb'

urlpatterns = [
    path('home', views.home,name='home'),
    path('order', views.order, name='order'),
]


