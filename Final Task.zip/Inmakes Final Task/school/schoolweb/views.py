from django.shortcuts import render


# Create your views here.
def home(request):
    return render(request,"index.html")

def order(request):
        if request.method == 'POST':
            name = request.POST.get('name')
            dob = request.POST.get('dob')
            age = request.POST.get('age')
            gender = request.POST.get('gender')
            phone = request.POST.get('phone')
            email = request.POST.get('email')
            address = request.POST.get('address')
            courses = request.POST.get('courses')
            department = request.POST.get('department')
            purpose = request.POST.get('purpose')
            materials = request.POST.getlist('materials')
            message = "Order Confirmed"
            return render(request, 'form.html', {'message': message})
        return render(request, 'form.html')

